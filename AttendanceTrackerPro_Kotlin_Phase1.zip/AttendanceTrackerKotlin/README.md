# Attendance Tracker Pro — Kotlin migration (Phase 1)

This is a native Android/Jetpack Compose starter project with:
- Kotlin dashboard and bottom navigation
- Initial attendance counter UI
- Native Android `PdfRenderer` PDF preview
- PDF file picker using Android Storage Access Framework
- Pinch zoom, drag, zoom buttons, fit/reset and previous/next page
- GitHub Actions workflow to build a debug APK in the cloud

## Build
GitHub Actions runs `gradle :app:assembleDebug`. Open the repository's **Actions** tab and run **Build Attendance Tracker APK**. Download the artifact named `Attendance-Tracker-Pro-debug-apk` after the workflow succeeds.

## Important migration note
The original HTML app is retained at `app/src/main/assets/original_app_reference.html` as a reference. It is not embedded as the active app UI. The dashboard and PDF preview are native Kotlin, while the other original feature areas are scaffolded and must be migrated feature-by-feature before this can replace the full HTML app. Attendance values in this starter are in-memory only and are not yet persisted.
