package com.attendancetracker.pro

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.rememberTransformableState
import androidx.compose.foundation.gestures.transformable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.roundToInt

private val Ink = Color(0xFF111827)
private val SurfaceDark = Color(0xFF1F2937)
private val Teal = Color(0xFF14B8A6)
private val SoftCyan = Color(0xFF67E8F9)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AttendanceApp(this) }
    }
}

private enum class Screen(val title: String) {
    HOME("Dashboard"), ATTENDANCE("Attendance"), TIMETABLE("Timetable"),
    STUDY("Study Hub"), INSIGHTS("Insights"), PDF("PDF Preview"), PROFILE("Profile")
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AttendanceApp(context: Context) {
    var screen by remember { mutableStateOf(Screen.HOME) }
    var present by remember { mutableIntStateOf(0) }
    var absent by remember { mutableIntStateOf(0) }
    var pdfUri by remember { mutableStateOf<Uri?>(null) }
    val pickPdf = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            pdfUri = uri
            screen = Screen.PDF
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Teal, secondary = SoftCyan, background = Ink,
        surface = SurfaceDark, onPrimary = Color.Black, onBackground = Color.White,
        onSurface = Color.White
    )) {
        Scaffold(
            containerColor = Ink,
            topBar = {
                TopAppBar(
                    title = { Text("Attendance Tracker Pro", fontWeight = FontWeight.Bold, fontSize = 18.sp) },
                    actions = { IconButton(onClick = { pickPdf.launch(arrayOf("application/pdf")) }) { Icon(Icons.Default.PictureAsPdf, "Open PDF") } },
                    colors = TopAppBarDefaults.topAppBarColors(containerColor = Ink, titleContentColor = Color.White)
                )
            },
            bottomBar = {
                NavigationBar(containerColor = SurfaceDark) {
                    listOf(Screen.HOME, Screen.ATTENDANCE, Screen.TIMETABLE, Screen.STUDY, Screen.PROFILE).forEach { item ->
                        NavigationBarItem(selected = screen == item, onClick = { screen = item },
                            icon = { Icon(when(item) {
                                Screen.HOME -> Icons.Default.Home
                                Screen.ATTENDANCE -> Icons.Default.FactCheck
                                Screen.TIMETABLE -> Icons.Default.CalendarMonth
                                Screen.STUDY -> Icons.Default.MenuBook
                                else -> Icons.Default.Person
                            }, contentDescription = item.title) },
                            label = { Text(item.title, fontSize = 9.sp) })
                    }
                }
            }
        ) { padding ->
            Box(Modifier.fillMaxSize().padding(padding)) {
                when (screen) {
                    Screen.HOME -> HomeScreen(present, absent, onAttendance = { screen = Screen.ATTENDANCE }, onPdf = { pickPdf.launch(arrayOf("application/pdf")) }, onInsights = { screen = Screen.INSIGHTS })
                    Screen.ATTENDANCE -> AttendanceScreen(present, absent, { present++ }, { absent++ }, { if (present > 0) present-- }, { if (absent > 0) absent-- })
                    Screen.TIMETABLE -> SimpleScreen("Timetable", "Your weekly class schedule will appear here.", Icons.Default.CalendarMonth)
                    Screen.STUDY -> SimpleScreen("Study Hub", "Notes, objective tests and subject-wise learning modules.", Icons.Default.MenuBook)
                    Screen.INSIGHTS -> SimpleScreen("Insights", "Attendance analytics and performance charts will appear here.", Icons.Default.Insights)
                    Screen.PROFILE -> SimpleScreen("Student Profile", "Name, roll number, semester, branch and college details.", Icons.Default.Person)
                    Screen.PDF -> PdfPreviewScreen(context, pdfUri, onChoose = { pickPdf.launch(arrayOf("application/pdf")) })
                }
            }
        }
    }
}

@Composable
private fun HomeScreen(present: Int, absent: Int, onAttendance: () -> Unit, onPdf: () -> Unit, onInsights: () -> Unit) {
    val total = present + absent
    val percent = if (total == 0) 0 else (present * 100f / total).roundToInt()
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        item {
            Text("Welcome back", color = SoftCyan, fontSize = 14.sp)
            Text("Your study dashboard", color = Color.White, fontSize = 25.sp, fontWeight = FontWeight.Bold)
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.fillMaxWidth().padding(18.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Attendance overview", color = Color.White, fontWeight = FontWeight.SemiBold)
                    Text("$percent%", color = Teal, fontSize = 38.sp, fontWeight = FontWeight.Bold)
                    LinearProgressIndicator(progress = { percent / 100f }, modifier = Modifier.fillMaxWidth().height(9.dp).clip(CircleShape), color = Teal, trackColor = Color(0xFF374151))
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Present: $present", color = SoftCyan)
                        Text("Absent: $absent", color = Color(0xFFF87171))
                    }
                }
            }
        }
        item { ActionCard("Mark attendance", "Record present or absent days", Icons.Default.FactCheck, onAttendance) }
        item { ActionCard("Insights", "Review your attendance progress", Icons.Default.Insights, onInsights) }
        item { ActionCard("PDF Library / Preview", "Open a PDF with zoom and page controls", Icons.Default.PictureAsPdf, onPdf) }
        item { Text("Kotlin migration · Phase 1", color = Color.Gray, fontSize = 12.sp) }
    }
}

@Composable
private fun AttendanceScreen(present: Int, absent: Int, addPresent: () -> Unit, addAbsent: () -> Unit, undoPresent: () -> Unit, undoAbsent: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(18.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Attendance", color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        StatCard("Present days", present.toString(), Teal)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = addPresent, modifier = Modifier.weight(1f)) { Icon(Icons.Default.Add, null); Text("Present") }
            OutlinedButton(onClick = undoPresent, modifier = Modifier.weight(1f)) { Text("Undo present") }
        }
        StatCard("Absent days", absent.toString(), Color(0xFFF87171))
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Button(onClick = addAbsent, modifier = Modifier.weight(1f), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB91C1C))) { Icon(Icons.Default.Add, null); Text("Absent") }
            OutlinedButton(onClick = undoAbsent, modifier = Modifier.weight(1f)) { Text("Undo absent") }
        }
        Text("This first build keeps counts in memory only. Persistent database and calendar-based records are part of the next migration phase.", color = Color.LightGray, fontSize = 12.sp)
    }
}

@Composable
private fun StatCard(label: String, value: String, tint: Color) {
    Card(colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(18.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(label, color = Color.White)
            Text(value, color = tint, fontSize = 28.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun ActionCard(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Card(onClick = onClick, colors = CardDefaults.cardColors(containerColor = SurfaceDark), shape = RoundedCornerShape(18.dp)) {
        Row(Modifier.fillMaxWidth().padding(17.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Icon(icon, null, tint = Teal, modifier = Modifier.size(30.dp))
            Column(Modifier.weight(1f)) { Text(title, color = Color.White, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Color.LightGray, fontSize = 12.sp) }
            Icon(Icons.Default.ChevronRight, null, tint = Color.Gray)
        }
    }
}

@Composable
private fun SimpleScreen(title: String, description: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(14.dp), horizontalAlignment = Alignment.Start) {
        Icon(icon, null, tint = Teal, modifier = Modifier.size(44.dp))
        Text(title, color = Color.White, fontSize = 26.sp, fontWeight = FontWeight.Bold)
        Text(description, color = Color.LightGray)
        Text("This screen is scaffolded in native Kotlin. Feature-by-feature migration is next.", color = SoftCyan, fontSize = 12.sp)
    }
}

@Composable
private fun PdfPreviewScreen(context: Context, uri: Uri?, onChoose: () -> Unit) {
    var pageIndex by remember(uri) { mutableIntStateOf(0) }
    var pageCount by remember(uri) { mutableIntStateOf(0) }
    var bitmap by remember(uri, pageIndex) { mutableStateOf<Bitmap?>(null) }
    var error by remember(uri) { mutableStateOf<String?>(null) }
    var scale by remember(uri, pageIndex) { mutableFloatStateOf(1f) }
    var offsetX by remember(uri, pageIndex) { mutableFloatStateOf(0f) }
    var offsetY by remember(uri, pageIndex) { mutableFloatStateOf(0f) }

    LaunchedEffect(uri, pageIndex) {
        bitmap = null; error = null
        if (uri != null) {
            try {
                val result = withContext(Dispatchers.IO) { renderPdfPage(context, uri, pageIndex) }
                bitmap = result.first
                pageCount = result.second
            } catch (e: Exception) { error = e.message ?: "Unable to open this PDF" }
        }
    }
    val transform = rememberTransformableState { zoom, pan, _ ->
        scale = (scale * zoom).coerceIn(1f, 5f)
        offsetX += pan.x; offsetY += pan.y
    }
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("PDF Preview", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 21.sp)
            TextButton(onClick = onChoose) { Icon(Icons.Default.FolderOpen, null); Text(" Open PDF") }
        }
        if (uri == null) {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Icon(Icons.Default.PictureAsPdf, null, tint = Teal, modifier = Modifier.size(60.dp)); Text("Select a PDF to preview", color = Color.White); Button(onClick = onChoose) { Text("Choose PDF") } } }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth().background(Color(0xFF374151), RoundedCornerShape(14.dp)).clip(RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                when {
                    error != null -> Text(error!!, color = Color(0xFFFCA5A5), modifier = Modifier.padding(18.dp))
                    bitmap == null -> CircularProgressIndicator(color = Teal)
                    else -> androidx.compose.foundation.Image(
                        bitmap = bitmap!!.asImageBitmap(), contentDescription = "PDF page ${pageIndex + 1}",
                        modifier = Modifier.fillMaxWidth().padding(8.dp).graphicsLayer(scaleX = scale, scaleY = scale, translationX = offsetX, translationY = offsetY).transformable(transform)
                    )
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                TextButton(enabled = pageIndex > 0, onClick = { pageIndex--; scale = 1f; offsetX = 0f; offsetY = 0f }) { Icon(Icons.Default.ChevronLeft, null); Text("Previous") }
                Text(if (pageCount > 0) "Page ${pageIndex + 1} / $pageCount" else "Loading…", color = Color.White)
                TextButton(enabled = pageCount > 0 && pageIndex < pageCount - 1, onClick = { pageIndex++; scale = 1f; offsetX = 0f; offsetY = 0f }) { Text("Next"); Icon(Icons.Default.ChevronRight, null) }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                OutlinedButton(onClick = { scale = 1f; offsetX = 0f; offsetY = 0f }) { Icon(Icons.Default.FitScreen, null); Text(" Fit / Reset") }
                Spacer(Modifier.width(10.dp))
                OutlinedButton(onClick = { scale = (scale + 0.25f).coerceAtMost(5f) }) { Icon(Icons.Default.ZoomIn, null); Text(" Zoom") }
                Spacer(Modifier.width(10.dp))
                OutlinedButton(onClick = { scale = (scale - 0.25f).coerceAtLeast(1f) }) { Icon(Icons.Default.ZoomOut, null); Text(" Out") }
            }
            Text("Pinch with two fingers to zoom; drag to move the page.", color = Color.LightGray, fontSize = 11.sp)
        }
    }
}

private fun renderPdfPage(context: Context, uri: Uri, index: Int): Pair<Bitmap, Int> {
    val descriptor: ParcelFileDescriptor = context.contentResolver.openFileDescriptor(uri, "r") ?: error("Cannot access this PDF")
    descriptor.use { pfd ->
        PdfRenderer(pfd).use { renderer ->
            require(renderer.pageCount > 0) { "This PDF has no pages" }
            val safeIndex = index.coerceIn(0, renderer.pageCount - 1)
            renderer.openPage(safeIndex).use { page ->
                val maxWidth = 1800
                val ratio = maxWidth.toFloat() / page.width
                val width = maxWidth
                val height = (page.height * ratio).roundToInt().coerceAtLeast(1)
                val image = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                image.eraseColor(android.graphics.Color.WHITE)
                page.render(image, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                return image to renderer.pageCount
            }
        }
    }
}
